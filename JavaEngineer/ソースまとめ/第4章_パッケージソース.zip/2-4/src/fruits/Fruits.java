package fruits;

public class Fruits {

    public static void printFruits(String fruits, int count) {
        System.out.println("食べ物は" + fruits);
        System.out.println(count + "個です");
    }
}